2007.11.11

Mapper fixes and additions:
 [Mapper004] fixed for "Feng Yun (C)"
 [Mapper047] fixed for "Super 2-in-1"
 [Mapper071] fixed for "PEGASUS 5 IN 1 (unl)"
 [Mapper074] rewrited for some WaiXing's games
 [Mapper163] fixed for some protected games(Info from CaH4e3)
 [Mapper175] a new mapper for "15-in-1(Kaiser)"
 [Mapper176] a new mapper for some ShuQiYu's games
 [Mapper177] a new mapper for some HengGe's games
 [Mapper178] a new mapper for some Education&WaiXing&HengGe's games
 [Mapper242] fixed for the mirroring
 [Mapper253] a new mapper for "Shen Hua Jian Yun III (C)"
